# Banco Nacional de Arapovina — Cloudflare Workers + D1

Sistema online compartilhado: todas as pessoas acessam o mesmo Worker e os mesmos dados D1.

ADM inicial: admin / arapovina

## Publicação pelo celular
1. Abra github.com no navegador e crie um repositório vazio chamado banco-arapovina.
2. Em Add file > Upload files, envie worker.js, schema.sql e wrangler.jsonc. O README é opcional.
3. No Cloudflare Dashboard, abra Workers & Pages > Create application > Import a repository.
4. Autorize GitHub, escolha banco-arapovina e faça Deploy.
5. Abra o Worker criado > Bindings > Add binding > D1 database. Nome da variável: DB. Selecione/crie banco-arapovina-db.
6. Abra D1 > banco-arapovina-db > Console. Cole TODO o conteúdo de schema.sql e execute.
7. Volte ao Worker e faça um novo Deploy/redeploy.
8. Abra a URL *.workers.dev do Worker.

A documentação atual da Cloudflare confirma que Workers podem ser conectados a GitHub para deploy automático e que D1 pode ser ligado por binding. O dashboard também permite editar Workers pelo navegador.
